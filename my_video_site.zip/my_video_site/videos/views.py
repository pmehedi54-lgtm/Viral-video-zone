from django.shortcuts import render
from django.core.paginator import Paginator
from .models import Video, SocialLink, Ad, Category

def index(request):
    video_list = Video.objects.all().order_by('-uploaded_at')
    # প্রতি পেজে ১০টি ভিডিও
    paginator = Paginator(video_list, 10) 
    page_number = request.GET.get('page')
    videos = paginator.get_page(page_number)
    
    social_links = SocialLink.objects.all()
    ad = Ad.objects.last() 
    categories = Category.objects.all()
    
    return render(request, 'videos/index.html', {
        'videos': videos, 
        'social_links': social_links, 
        'ad': ad,
        'categories': categories
    })