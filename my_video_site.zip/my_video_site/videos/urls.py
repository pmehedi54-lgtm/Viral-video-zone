from django.urls import path
from . import views

urlpatterns = [
    # হোমপেজের জন্য index ফাংশনটি ব্যবহার করা হচ্ছে
    path('', views.index, name='index'), 
]