from django.db import models

# ক্যাটাগরি কন্ট্রোল
class Category(models.Model):
    name = models.CharField(max_length=100)
    icon = models.CharField(max_length=10, help_text="ইমোজি দিন")

    def __str__(self):
        return self.name

# ভিডিও আপলোড
class Video(models.Model):
    title = models.CharField(max_length=200)
    video_file = models.FileField(upload_to='videos/')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# বিজ্ঞাপন কন্ট্রোল
class Ad(models.Model):
    platform_name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='ads/')
    link = models.URLField()

    def __str__(self):
        return self.platform_name

# সোশ্যাল মিডিয়া লিংক
class SocialLink(models.Model):
    platform_name = models.CharField(max_length=100)
    link = models.URLField()
    icon_emoji = models.CharField(max_length=10, default="🔗")

    def __str__(self):
        return self.platform_name

# কমেন্ট সেকশন (যাতে এরর না আসে)
class Comment(models.Model):
    video = models.ForeignKey(Video, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)