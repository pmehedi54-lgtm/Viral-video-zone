from django.contrib import admin
from .models import Video, Category, Ad, SocialLink, Comment

# ১. ভিডিও কন্ট্রোল (ভিডিও ফাইল এবং টাইটেল আপলোড)
@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'uploaded_at')
    list_filter = ('category',)
    search_fields = ('title',)

# ২. ক্যাটাগরি কন্ট্রোল (দেশের নাম ও পতাকার ইমোজি)
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon')

# ৩. অ্যাডস কন্ট্রোল (বিজ্ঞাপনের ছবি ও লিংক আপলোড)
@admin.register(Ad)
class AdAdmin(admin.ModelAdmin):
    list_display = ('platform_name', 'link')

# ৪. সোশ্যাল মিডিয়া কন্ট্রোল (ফেসবুক, টিকটক ইত্যাদি লিংক)
@admin.register(SocialLink)
class SocialLinkAdmin(admin.ModelAdmin):
    list_display = ('platform_name', 'link', 'icon_emoji')

# ৫. কমেন্ট কন্ট্রোল
admin.site.register(Comment)
